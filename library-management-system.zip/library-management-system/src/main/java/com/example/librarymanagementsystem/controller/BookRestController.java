package com.example.librarymanagementsystem.controller;


import com.example.librarymanagementsystem.entity.Book;
import com.example.librarymanagementsystem.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/book")


public class BookRestController {
    // Add all crud operations  here
    @Autowired
    private BookService bookService;

    @GetMapping("/all")
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookService.findAllBooks();
        if (books.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return new ResponseEntity<>(books, HttpStatus.OK);
        }

    }

    //Add new book
    @PostMapping("/add")
    public ResponseEntity<Long> addNewBook(@RequestBody Book book) {
        Book newBook = bookService.createBook(book);
        if (newBook == null) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(newBook.getId(), HttpStatus.OK);

    }
    @PostMapping("/update")
    public ResponseEntity UpdateBook(@RequestBody Book book) {
        bookService.updateBook(book);
        return new ResponseEntity<>(HttpStatus.OK);
    }
@DeleteMapping("/delete/{id}")
    public ResponseEntity deleteBook(@PathVariable("id") Long id) {
        bookService.deleteBook(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}

package com.example.librarymanagementsystem.service;

import com.example.librarymanagementsystem.entity.Book;

import java.util.List;
import java.util.Optional;

public interface BookService {
// Add all crud operations
      List<Book> findAllBooks();
      Book createBook(Book book);

      void deleteBook(Long id);

      void updateBook(Book book);

      Optional<Book> findBookById(Long id);



}
